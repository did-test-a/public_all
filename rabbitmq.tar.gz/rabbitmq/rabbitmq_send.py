import pika
credentials = pika.PlainCredentials('rabbitmq', 'rabbitmq_test2020')
connection = pika.BlockingConnection(pika.ConnectionParameters(
                                                    '192.168.2.9',
                                                    5672,
                                                    '/',
                                                    credentials))
channel = connection.channel()

channel.queue_declare(queue='my_queue')
channel.basic_publish(exchange='',
                      routing_key='my_queue',
                      body='Hello World!')
print(" [x] Sent 'Hello World!'")
connection.close()
