import pika
credentials = pika.PlainCredentials('rabbitmq', 'rabbitmq_test2020')
connection = pika.BlockingConnection(pika.ConnectionParameters(
                                                    '192.168.2.9',
                                                    5672,
                                                    '/',
                                                    credentials))
channel = connection.channel()

method_frame, header_frame, body = channel.basic_get('my_queue')
print('method ',method_frame)
if method_frame:
    print(method_frame, header_frame, body)
    channel.basic_ack(method_frame.delivery_tag)
else:
    print('No messages')


